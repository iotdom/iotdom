<?php
/*ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);*/
require "model/biblioteca.php";
$caminho = "index.php?rotina=";

//adiciona bibliotecas js e css
?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/datatables.min.css">
  <link rel="stylesheet" type="text/css" href="css/navbar_menu.css">
  <link rel="stylesheet" type="text/css" href="css/Chart.min.css">
  <link rel="stylesheet" type="text/css" href="js/chosen_v1.8.7/chosen.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/spectrum-colorpicker2/dist/spectrum.min.css" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script type="text/javascript" src="js/jquery.js" ></script>
  <script type="text/javascript" src="js/popper.min.js" ></script>
  <script type="text/javascript" src="js/bootstrap.min.js" ></script>
  <script type="text/javascript" src="js/Jquery_Validade/jquery.validate.min.js"></script>
  <script type="text/javascript" src="js/Jquery_Validade/form_validate_messages_pt_br.js"></script>
  <script type="text/javascript" src="js/Jquery_Validade/form_validate.js"></script>
  <script type="text/javascript" src="js/Jquery_Mask/jquery.mask.min.js" ></script>
  <script type="text/javascript" src="js/Jquery_Mask/form_mask.js" ></script>
  <script type="text/javascript" src="js/Datatable/datatables.min.js" ></script>
  <script type="text/javascript" src="js/Datatable/form_datatables.js" ></script>
  <script type="text/javascript" src="js/bootbox.min.js"></script>
  <script type="text/javascript" src="js/Chart.min.js"></script>
  <script type="text/javascript" src="js/chosen_v1.8.7/chosen.jquery.js" ></script>
  <script type="text/javascript" src="js/script.js" ></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <script src="https://www.gstatic.com/charts/loader.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/spectrum-colorpicker2/dist/spectrum.min.js"></script>
  
  <!-- Carrega Controllers -->
  <script type="text/javascript" src="controller/jquery_tomada_controller.js" ></script>
  
  <!-- inicia todos os elementos com tooltip -->
  <script>
    $(document).ready(function(){
       $(function () {
         //inicia a classe de tooltip
         $('[data-toggle="tooltip"]').tooltip();
       })  
    });
   </script>
<?php

if(!isset($_SESSION["autenticado"])):

  $master = new Master($banco);
  $login = $master->valida_login($_POST);

  if(!$login['valido']):
    if(!empty($_POST)):
    $erro_login =  $login['mensagem'];
    endif;
    
    if($_GET['rotina'] === 'view/cadastro.php'){
      $rotina = $_GET['rotina'];
    }else{
      $rotina = "view/login.php";
    }
    
  else:
    if($_GET['rotina'] !== null and $_GET['rotina'] !== ""): 
      $rotina_seq = $_GET['rotina'];
    else:
      $rotina_seq = "analises.php";
    endif;
      $rotina = "view/home.php";  
  endif;

else:

  if($_GET['rotina'] !== null and $_GET['rotina'] !== ""): 
    $rotina_seq = $_GET['rotina'];
  else:
    $rotina_seq = "analises.php";  
  endif;
    $rotina = "view/home.php";
    
endif;  
require_once($rotina);
?>