<?php

$slave = new Slave($banco,$_SESSION[id_master]);

$dados_fluxo = $slave->corrente_fluxo();

$dados_ini = get_dados_ini_real_time_fluxo_corrente();

//var_dump($dados_ini);

?>
<!DOCTYPE>
<html>
 <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
 </head>
 <script>
   $(document).ready(function(){
    
   ctx = $("#real_time_fluxo_corrente");
   
   
   var myLineChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [
        <? 
        $itens = count($dados_ini);
        $aux_itens = 0;
        foreach($dados_ini as $d):
        ?>
        {
            label: "<?=$d[name_relay]?>",
            data: ["<?=$d[kpotencia]?>"],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }
        
        <?if($aux_itens < $itens):
         //ajuste de virgula
         echo ",";
        endif;?>
        
        <?endforeach;?>
        ]
    }
   });

   atualiza_real_time_fluxo_corrente(myLineChart);

});

  </script>
 <body>
    <div class="container-fluid">
     <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
       <div class="page-header">
        <h3 class="mb-2">Análises de consumo</h3>
        <hr/>
       </div>
      </div>
     </div>
     <div class="row">
      <div class="offset-xl-9 col-xl-3 col-lg-3 col-md-7 col-sm-12 col-12">
        <form class='form-inline'>
         <h5 class="mr-sm-2">Tipo de Fluxo:</h5>
          <select name='tp_fluxo' id='tp_fluxo' class="form-control">
           <option value = '1' >Diario</option>
           <option value = '2' >Semanal</option>
           <option value = '3' >Mensal</option>
           <option value = '4' >Semestral</option>
          </select>
         </form>
        </div>
       </div>
       <div class="row">
       <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
        <div class="card">
         <h5 class="card-header">kW/h Semestral</h5>
          <div class="card-body">
           <div class="metric-value d-inline-block">
            <h1 class="mb-1"><?=number_format($dados_fluxo[semestral][total_valor_kwh], 2, ',', '.')."kW/h"?></h1>
           </div>
           <div class="metric-label d-inline-block float-right text-success font-weight-bold">
             <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">0%</span>
           </div>
          </div>
          <div class="card-body bg-light p-t-40 p-b-40">
           <div id="sparkline-revenue"></div>
          </div>
          <div class="card-footer text-center bg-white">
            <a href="#" class="card-link">Ver Detalhes</a>
          </div>
         </div>
         </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">kW/h Mensal</h5>
                                <div class="card-body">
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1"><?=number_format($dados_fluxo[mensal][total_valor_kwh], 2, ',', '.')."kW/h"?></h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-secondary font-weight-bold">
                                        <span class="icon-circle-small icon-box-xs text-danger bg-danger-light"><i class="fa fa-fw fa-arrow-down"></i></span><span class="ml-1">0%</span>
                                    </div>
                                </div>
                                <div class="card-body text-center bg-light p-t-40 p-b-40">
                                    <div id="sparkline-revenue2"></div>
                                </div>
                                <div class="card-footer text-center bg-white">
                                    <a href="#" class="card-link">Ver Detalhes</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">kW/h Semanal</h5>
                                <div class="card-body">
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1"><?=number_format($dados_fluxo[semanal][total_valor_kwh], 2, ',', '.')."kW/h"?></h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                        <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">0%</span>
                                    </div>
                                </div>
                                <div class="card-body bg-light p-t-40 p-b-40">
                                    <div id="sparkline-revenue3"></div>
                                </div>
                                <div class="card-footer text-center bg-white">
                                    <a href="#" class="card-link">Ver Detalhes</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">kW/h Diario</h5>
                                <div class="card-body">
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1"><?=number_format($dados_fluxo[diario][total_valor_kwh], 2, ',', '.')."kW/h"?></h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                        <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span> <span class="ml-1">0%</span>
                                    </div>
                                </div>
                                <div class="card-body bg-light p-b-40 p-t-40">
                                    <div id="sparkline-revenue4"></div>
                                </div>
                                <div class="card-footer text-center bg-white">
                                    <a href="#" class="card-link">Ver Detalhes</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                     <h5 class="card-header">Fluxo de kW/h</h5>
                      <div class="card-body">
                      <div class="row justify-content-center">
                       <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                       <div class="chart-container">
                        <canvas id="real_time_fluxo_corrente"></canvas>
                       </div> 
                       </div>
                      </div> 
                      </div> 
                     </div>
                    </div>
                   </div>  
    </div>
 </body>
 </html>