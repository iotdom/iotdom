function modal_carregamento(){
  bootbox.dialog({ 
    message: '<div id="loading_modal_alert" class="text-center"><img class="loading_modal_img" src="img/animated_light_bulb.gif" alt="loading_modal_img"><br/><b>Carregando...</b></div>', 
    closeButton: false 
   })
}

function inicia_real_time_fluxo_corrente(){

    $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes.php',
      data: {funcao:"get_dados_real_time_fluxo_corrente"},
      success: function (resultado) {
        retorno = JSON.parse(resultado);
        
      }
    });
    
}

function atualiza_real_time_fluxo_corrente(chart,lab_ini){
   new_lab = lab_ini + 5;
   $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes.php',
      data: {funcao:"get_dados_real_time_fluxo_corrente"},
      success: function (resultado) {
       setTimeout(function() {  
        dados = JSON.parse(resultado);
        console.log(dados);
        
        chart.data.labels.push(new_lab);
         
        $.each(dados, function( index, dado ) {
          chart.data.datasets.forEach((dataset) => {
           dataset.data.push(dado['kpotencia']);
         });
         
        });
        
        chart.update();

        atualiza_real_time_fluxo_corrente(chart,lab_ini + 5);
      }, 5000); 
    } 
   }); 
    
}

function at_alert_analise(id_master){

   $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes.php',
      data: {funcao:"at_alert_analise",id_master: id_master},
      success: function (resultado) {
        
       setTimeout(function() {  
        
        $("#alert_div").removeClass();   
        if(resultado < 50){
            $("#alert_div").addClass("alert alert-success");
        }else if(resultado < 80){
            $("#alert_div").addClass("alert alert-warning");
        }else{
            $("#alert_div").addClass("alert alert-danger");
        }
        
        $("#alert_bar").css("width",resultado + "%");
        $("#alert_bar").text(resultado + "%");
        $("#alert_val_txt").text(resultado + "%");
        
        
        at_alert_analise(id_master);
        
      }, 5000); 
    } 
   }); 
    
}

function grava_sala(id_form){
  window.location="controller/sala_controller.php?opc=gravar&" + $('#'+id_form).serialize();
}

function deleta_sala(id_sala){
  window.location="controller/sala_controller.php?opc=deletar&id_sala="+id_sala;
}

function grava_usuario(id_form){
  window.location="controller/usuario_controller.php?opc=gravar&" + $('#'+id_form).serialize();
}

function deleta_usuario(id_usuario){
  window.location="controller/usuario_controller.php?opc=deletar&id_usuario="+id_usuario;
}

function edita_sala(id_sala,nr_sala,cd_unidade,tp_sala,op_manha,op_tarde,op_noturno,ds_sala){

 $("#id_sala").val(id_sala);
 $("#nr_sala").val(nr_sala);
 $("#cd_unidade").val(cd_unidade);
 $("#tp_sala").val(tp_sala);
 if(op_manha === 'S'){
  $("#op_manha").prop( "checked", true );
 }
 if(op_tarde === 'S'){
  $("#op_tarde").prop( "checked", true );
 }
 if(op_noturno === 'S'){
  $("#op_noturno").prop( "checked", true );
 }
 $("#ds_sala").val(ds_sala);
 $('#modal_sala').modal('toggle');

}

function reserva_sala(id_sala,nr_sala,cd_unidade,ds_sala,op_manha,op_tarde,op_noturno){

  $("#id_sala").val(id_sala);
  $("#nr_sala").text(nr_sala);
  $("#cd_unidade").text(cd_unidade);
  $("#ds_sala").text(ds_sala);
  $("#ds_sala_titulo").text(ds_sala);
  $('#modal_reserva_sala').modal('toggle');

  if(op_manha === 'S'){
    $("#op_manha").prop( "checked", true );
    $("#div_manha").removeClass("hidden");
   }else{
    $("#div_manha").addClass("hidden");
   }

   if(op_tarde === 'S'){
    $("#op_tarde").prop( "checked", true );
    $("#div_tarde").removeClass("hidden");
  }else{
   $("#div_tarde").addClass("hidden");
  }

   if(op_noturno === 'S'){
    $("#op_noturno").prop( "checked", true );
    $("#div_noturno").removeClass("hidden");
  }else{
   $("#div_noturno").addClass("hidden");
  }
 
 }

 function grava_reserva(id_form){
  window.location="controller/reserva_controller.php?opc=gravar&" + $('#'+id_form).serialize();
}


 function edita_usuario(id_usuario,nm_usuario,cd_registro_usuario,senha,tp_usuario,email_usuario,tel_usuario){

  $("#id_usuario").val(id_usuario);
  $("#nm_usuario").val(nm_usuario);
  $("#cd_registro_usuario").val(cd_registro_usuario);
  $("#senha").val(senha);
  $("#tp_usuario").val(tp_usuario);
  $("#email_usuario").val(email_usuario);
  $("#tel_usuario").val(tel_usuario);
  $('#modal_usuario').modal('toggle');
 
 }
 
 function inclui_usuario(){
 
  $("#id_usuario").val("");
  $("#nm_usuario").val("");
  $("#cd_registro_usuario").val("");
  $("#senha").val("");
  $("#tp_usuario").val("");
  $("#email_usuario").val("");
  $("#tel_usuario").val("");
   $('#modal_usuario').modal('toggle');
  
  }
  
  function modal_info_sobre(){
    $("#modal_sobre").modal("show");
  }

$(document).ready(function () {
  $("#menu-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("active");
});


});