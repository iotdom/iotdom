<?php
class Master {

  private $dados_master;
  private $banco;
  private $tabela = "placa_master";


    //Open Connection
    function __construct($banco,$id_master = null){
      $this->banco = $banco;
      $this->master = $id_master;
        if(!empty($id_master)):
          $id_master = $this->banco->getRegistros($this->tabela,array("id_master" => $id_master))[0];
          $this->dados_master = $id_master;
        endif; 
    }

    public function get_dados(){
      return $this->dados_master;
    }

  }
?>