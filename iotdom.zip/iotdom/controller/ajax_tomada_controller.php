<?php
require "../model/biblioteca.php";

foreach ($_POST as $nome_campo => $valor):
  $data[$nome_campo] = $valor;
endforeach;

$form = array();
$label = array();

if (!empty($data[form])):
  foreach ($data[form] as $dado):
      
      if(is_string($dado[value])):
       $form[$dado[name]] = utf8_decode($dado[value]);
      else:
       $form[$dado[name]] = $dado[value];
      endif;
      
  endforeach;
endif;

if(!empty($data[label])):
foreach($data[label] as $key => $dado):

 if(is_string($dado)):
       $label[$key] = utf8_decode($dado);
      else:
       $label[$key] = $dado;
 endif;

endforeach; 
endif;

$banco = new Banco();

$relay = new Slave($banco,$form[id_master],$form[id_slave]);

if($data[funcao] === "update_tomada"):

   $retorno = $relay->update_relay($form); 

   if($retorno[erro] === true or $retorno[erro] === 'true'):
     $ret = $retorno;
   else:
     $ret = $relay->lista_dados();
   endif; 

   echo json_encode($ret);

endif;

if($data[funcao] === "ativa_desativa_relay"){
  $id_relay = $data[id_slave];
  $relay = new Slave($banco,$data[id_master],$data[id_slave]);
  $result = $relay->ativa_desativa_relay();
  echo json_encode($result);
}

if($data[funcao] === "get_dados_slave"){
  $relay = new Slave($banco,$data[id_master],$data[id_slave]);
  $dados = $relay->lista_dados();
  require_once "../view/form_tomada.php";
  //echo json_encode($result);
}

if($data[funcao] === "carrega_tomadas"){
  require_once "../view/tomadas.php";
  //echo json_encode($result);
}

?>