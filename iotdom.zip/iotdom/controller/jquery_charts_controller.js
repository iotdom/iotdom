function ini_chart_real_time(){
    $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes_charts.php',
      data: {funcao:"ini_chart_real_time"},
      success: function (html) {
      console.log(html);  
      $("#view_chart").html(html);
    } 
   }); 
}

function update_chart_real_time(chart,lab_ini){
   
   //verifica se o elemento do gr�fico existe para continuar com o loop
   if($("#chart_real_time").length){
   new_lab = lab_ini + 5;
   $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes_charts.php',
      data: {funcao:"get_last_data_chart_real_time"},
      success: function (resultado) {
       setTimeout(function() {  
        dados = JSON.parse(resultado);
        chart.data.labels.push(new_lab+"s");
        
        potencia = new Array();
        
        $.each(dados, function( index, dado ) {
          potencia.push(dado['kpotencia']);
        });
        
        chart.data.datasets.forEach((dataset,indice) => {
           dataset.data.push(potencia[indice]);
         });

        chart.update();
        
        update_chart_real_time(chart,lab_ini + 5);
        
      }, 5000); 
    } 
   }); 
  }  
}

function ini_chart_consumo_diario(){
    $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes_charts.php',
      data: {funcao:"ini_chart_consumo_diario"},
      success: function (html) {
      console.log(html);  
      $("#view_chart").html(html);
    } 
   }); 
}

function update_chart_consumo_diario(chart,dt_ini, dt_fim){
   
   //verifica se o elemento do gr�fico existe para continuar com o loop
   $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes_charts.php',
      data: {funcao:"update_chart_consumo_diario",dt_ini:dt_ini,dt_fim:dt_fim},
      success: function (resultado) {

        dados = JSON.parse(resultado);
        
        chart.data.datasets[0].data[0] = dados[0];
        chart.data.datasets[0].data[1] = dados[1];
        chart.data.datasets[0].data[2] = dados[2];
        
        chart.update();

    } 
   }); 
 
}

function ini_chart_tarifas(){
    $.ajax({
      type: 'POST',
      url: 'model/ajax_funcoes_charts.php',
      data: {funcao:"ini_chart_tarifas"},
      success: function (html) {
      console.log(html);  
      $("#view_chart").html(html);
    } 
   }); 
}