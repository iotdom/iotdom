  function carrega_tomadas(){
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_tomada_controller.php',
      data: {funcao: "carrega_tomadas"},
      success: function (html) {
        setTimeout(function() { 
          console.log(html);
          $("#card_rotina").html(html);  
          bootbox.hideAll();
        }, 500);  
      }
    });
   }

  function grava_tomada(id_form){
    modal_carregamento();
    form = $('#'+id_form).serializeArray();
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_tomada_controller.php',
      data: {funcao:"update_tomada",form:form},
      success: function (resultado) {
        setTimeout(function() { 
        retorno = JSON.parse(resultado);
         if(retorno['erro'] === true || retorno['erro'] === 'true'){
          bootbox.hideAll(); 
          bootbox.alert("<div class='alert alert-warning'>Ops... Ocorreu um problema na operação, por favor tente novamente.</div>");
         }else{
           /*
          
          tomada = $("#card_tomada_" + retorno['id_slave']);
          tomada.find($("#name_relay_" + retorno['id_slave'])).text(retorno['name_relay']);
          if( (retorno['relay_hr_off'] === null || retorno['relay_hr_off'] === "") &&  (retorno['relay_hr_on'] === null || retorno['relay_hr_on'] === "")){
            tomada.find("#alert_function_tomada_"+ retorno['id_slave']).addClass('hidden');
          } */
          modal_tomada = $('#modal_form_tomada').modal('toggle');  
          modal_tomada.modal('hide');
          carrega_tomadas();
          bootbox.hideAll();
         }
        }, 500);
      }
    });
  }

  function ativa_desativa_relay(id_master,id_slave){
    modal_carregamento();
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_tomada_controller.php',
      data: {funcao: "ativa_desativa_relay",id_master:id_master,id_slave: id_slave},
      success: function (resultado) {
        setTimeout(function() { 
        retorno = JSON.parse(resultado);
         if(retorno['erro'] === true || retorno['erro'] === 'true'){
          bootbox.hideAll(); 
          bootbox.alert("<div class='alert alert-warning'>Ops... Ocorreu um problema na operação, por favor tente novamente.</div>");
         }else{
          
          if(retorno['new_status'] === 1 || retorno['new_status'] === '1'){
            new_classe_status = "success";
            old_classe_status = "danger";
            img_status = "img/lighting.png";
          }else{
            new_classe_status = "danger";
            old_classe_status = "success";
            img_status = "img/plug.png";
          }

          $("#card_tomada_" + retorno['id_slave']).removeClass("border-"+old_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_header").removeClass("border-"+old_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_footer").removeClass("border-"+old_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_button").removeClass("btn-outline-"+old_classe_status);
        
          $("#card_tomada_" + retorno['id_slave']).addClass("border-"+new_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_header").addClass("border-"+new_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_footer").addClass("border-"+new_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_button").addClass("btn-outline-"+new_classe_status);
          $("#card_tomada_" + retorno['id_slave'] + "_img").attr("src", img_status);
          bootbox.hideAll();
         }
        }, 500);
      }
    });
  }


  function form_tomada(id_master,id_slave){
    modal_carregamento();
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_tomada_controller.php',
      data: {funcao: "get_dados_slave",id_master:id_master,id_slave:id_slave},
      success: function (html) {
        setTimeout(function() { 
          $("#div_form_tomada").html(html);
          $("#color").spectrum({
           type: "component",
           hideAfterPaletteSelect: true,
           showInput: true,
           showAlpha: false,
           allowEmpty: false
          });
          $('#modal_form_tomada').modal('toggle');
          bootbox.hideAll();
        }, 500);  
      }
    });
   }     

 function reset_tempo_tomada(){
   $("#relay_hr_on").val("");
   $("#relay_hr_off").val("");
 }  