function carrega_alerta(){
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_alert_controller.php',
      data: {funcao: "carrega_alerta"},
      success: function (html) {
        setTimeout(function() { 
          console.log(html);
          $("#card_rotina").html(html);  
          bootbox.hideAll();
        }, 500);  
      }
    });
}

function ativa_desativa_alerta(id_master){
  modal_carregamento();
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_alert_controller.php',
      data: {funcao: "ativa_desativa_alerta",id_master:id_master},
      success: function (resultado) {
        setTimeout(function() { 
        retorno = JSON.parse(resultado);
         if(retorno['erro'] === true || retorno['erro'] === 'true'){
          bootbox.hideAll(); 
          bootbox.alert("<div class='alert alert-warning'>Ops... Ocorreu um problema na opera��o, por favor tente novamente.</div>");
         }else{
          carrega_alerta();
         }
        }, 500);
      }
    });
  
}

function grava_alerta(id_form){
    modal_carregamento();
    form = $('#'+id_form).serializeArray();
    $.ajax({
      type: 'POST',
      url: 'controller/ajax_alert_controller.php',
      data: {funcao:"update_alerta",form:form},
      success: function (resultado) {
        setTimeout(function() { 
        retorno = JSON.parse(resultado);
         if(retorno['erro'] === true || retorno['erro'] === 'true'){
          bootbox.hideAll(); 
          bootbox.alert("<div class='alert alert-warning'>Ops... Ocorreu um problema na opera��o, por favor tente novamente.</div>");
         }else{
          carrega_alerta();
          bootbox.hideAll();
         }
        }, 500);
      }
    });
  }
  
$(document).ready(function(){
    
    $("#range_kwh").change(function(){
        //ajuste de decimais
        val = $(this).val()+"00";
        $("#vl_max_kwh").val(val);
        $("#vl_max_kwh").trigger('input');
    })
    
    $("#vl_max_kwh").change(function(){
        val = $(this).val().replace("kWh","");
        val = val.replace(".","");
        val = val.replace(",",".");
        $("#range_kwh").val(val);
    });
    
 })