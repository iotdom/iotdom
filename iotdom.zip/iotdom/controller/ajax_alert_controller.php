<?php
require "../model/biblioteca.php";

foreach ($_POST as $nome_campo => $valor):
  $data[$nome_campo] = $valor;
endforeach;

$form = array();
$label = array();

if (!empty($data[form])):
  foreach ($data[form] as $dado):
      
      if(is_string($dado[value])):
       $form[$dado[name]] = utf8_decode($dado[value]);
      else:
       $form[$dado[name]] = $dado[value];
      endif;
      
  endforeach;
endif;

if(!empty($data[label])):
foreach($data[label] as $key => $dado):

 if(is_string($dado)):
       $label[$key] = utf8_decode($dado);
      else:
       $label[$key] = $dado;
 endif;

endforeach; 
endif;

$banco = new Banco();

if($data[funcao] === "carrega_alerta"):
 require_once "../view/alertas.php";
endif;

if($data[funcao] === "ativa_desativa_alerta"):
 
 $alerta = new Alerta($banco,$data[id_master]);
 $retorno = $alerta->ativa_desativa_alerta();
 echo json_encode($retorno);
 
endif;

if($data[funcao] === "update_alerta"):
   
   $alerta = new Alerta($banco,$form[id_master]); 
   
   //trata valor kwh
   $form[vl_max_kwh] = str_replace("kWh","",$form[vl_max_kwh]);
   $form[vl_max_kwh] = remove_val_mask($form[vl_max_kwh]);
   
   //trara checkbox
   if($form[op_envio_email] !== null and $form[op_envio_email] !== ""):
    $form[op_envio_email] = "S";
   else:
    $form[op_envio_email] = "N";
   endif;
   
   if($form[op_envio_sms] !== null and $form[op_envio_sms] !== ""):
    $form[op_envio_sms] = "S";
   else: 
    $form[op_envio_sms] = "N";
   endif;

   $retorno = $alerta->update_alerta($form);

   if($retorno[erro] === true or $retorno[erro] === 'true'):
     $ret = $retorno;
   else:
     $ret = $alerta->lista_dados();
   endif; 

   echo json_encode($ret);

endif;


?>