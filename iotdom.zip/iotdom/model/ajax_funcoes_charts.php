<?php

require "biblioteca.php";
//Biblioteca Processos Ajax
foreach ($_POST as $nome_campo => $valor):
  $data[$nome_campo] = $valor;
endforeach;

$form = array();
$label = array();

if (!empty($data[form])):
  foreach ($data[form] as $dado):
      
      if(is_string($dado[value])):
       $form[$dado[name]] = utf8_decode($dado[value]);
      else:
       $form[$dado[name]] = $dado[value];
      endif;
      
  endforeach;
endif;

if(!empty($data[label])):
foreach($data[label] as $key => $dado):

 if(is_string($dado)):
       $label[$key] = utf8_decode($dado);
      else:
       $label[$key] = $dado;
 endif;

endforeach; 
endif;


$banco = new Banco();

if($data[funcao] === "ini_chart_real_time"){
  require_once "../view/charts/chart_real_time.php";
}

if($data[funcao] === "get_last_data_chart_real_time"){
  $dados = get_last_data_chart_real_time();
  echo json_encode($dados);
}

if($data[funcao] === "ini_chart_consumo_diario"){
  require_once "../view/charts/chart_consumo_diario.php";
}

if($data[funcao] === "update_chart_consumo_diario"){
  $dados = get_consumo_diario($data[dt_ini],$data[dt_fim]);
  echo json_encode($dados[dados]);
}

if($data[funcao] === "ini_chart_tarifas"){
  require_once "../view/charts/chart_tarifas.php";
}

?>