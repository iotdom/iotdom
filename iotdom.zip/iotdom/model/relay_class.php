<?php
class Slave {
  
  private $id_master;
  private $id_slave;
  private $dados_slave;
  private $banco;
  private $tabela = "placa_slave";


    //Open Connection
    function __construct($banco, $id_master,$id_slave = null){
      $this->banco = $banco;
      $this->id_master = $id_master;
        if(!empty($id_slave)):
          $slave = $this->banco->getRegistros($this->tabela,array("id_master" => $id_master,"id_slave" => $id_slave))[0];
          $this->dados_slave = $slave;
          $this->id_slave = $id_slave;
        endif; 
    }

    public function update_relay($dados){
      
      $oper = array();
      
      //ajuste de tempo
      $dados_time_on[relay_hr_on] = $dados[relay_hr_on] === "" ? 'NULL' : $dados[relay_hr_on];
      $dados_time_off[relay_hr_off] = $dados[relay_hr_off] === "" ? 'NULL' : $dados[relay_hr_off];

      unset($dados[relay_hr_on]);
      unset($dados[relay_hr_off]);

      $retorno = $this->banco->update($this->tabela,$dados," id_slave = ".$dados['id_slave']." ");

      $axus_on = $dados_time_on[relay_hr_on] !== "NULL" ? true : false;
      $axus_off = $dados_time_off[relay_hr_off] !== "NULL" ? true : false;

      $retorno_time_on = $this->banco->update($this->tabela,$dados_time_on," id_slave = ".$dados['id_slave']." ",$axus_on);
      $retorno_time_off = $this->banco->update($this->tabela,$dados_time_off," id_slave = ".$dados['id_slave']." ",$axus_off);

      if(empty($retorno['erro'])):
         $mensagem = "Tomada atualizada com sucesso!";
         $oper['erro'] = false;
         $this->dados_slave = $this->banco->getRegistros($this->tabela,array("id_master" => $this->id_master,"id_slave" => $this->id_slave))[0];
      else:
         $mensagem =  $retorno['erro'];
         $oper['erro'] = true;
      endif;
 
     $oper['mensagem'] = $mensagem;
 
     return $oper;
 
     }
    

    public function corrente( $dt_ini = null, $dt_fim = null ){
       
       $condicao = " 1 ";

       if($dt_ini !== null and $dt_ini !== ""){
          $condicao .= " and dt_leitura >= '$dt_ini' ";
       }

       if($dt_fim !== null and $dt_fim !== ""){
          $condicao .= " and dt_leitura <= '$dt_fim' ";
      }

       $dados = $this->banco->getRegistros($this->tabela,array("id_slave" => $this->$dados_slave['id_slave']),"*",$condicao);
       return $dados;
    }

    public function corrente_fluxo(){

      $fluxo[diario] = 0;
      $fluxo[semanal] = 0;
      $fluxo[mensal] = 0;
      $fluxo[semestral] = 0;

      $tabela = " fluxo_corrente ";
      $campos = " SUM( ((vl_corrente * tp_voltagem)/1000) ) AS total_kw, 

      time_format( SEC_TO_TIME( (COUNT(dt_leitura) * 5)),'%H:%i:%s') AS total_horas,
      
      ((COUNT(dt_leitura) * 5)/3600) AS total_valor_num_hora,
      
      (SUM( ((vl_corrente * tp_voltagem)/1000) ) / 3600) AS total_valor_kwh ";

      //busca dados diarios
      $condicao_diario = " DATE(dt_leitura) = CURRENT_DATE() ";
      $dados_diario = $this->banco->getRegistros($tabela,null,$campos,$condicao_diario);

      //busca dados semanais
      $condicao_semanal = " DATE(dt_leitura) >= CURRENT_DATE() - 7";
      $dados_semanal = $this->banco->getRegistros($tabela,null,$campos,$condicao_semanal);

      //busca dados mensais
      $condicao_mensais = " DATE(dt_leitura) >= CURRENT_DATE() - 30 ";
      $dados_mensais = $this->banco->getRegistros($tabela,null,$campos,$condicao_mensais);

      //busca dados semestrais
      $condicao_semestral = " DATE(dt_leitura) >= CURRENT_DATE() - 180 ";
      $dados_semestral = $this->banco->getRegistros($tabela,null,$campos,$condicao_semestral);
      
      $fluxo[diario] = $dados_diario[0];
      $fluxo[semanal] = $dados_semanal[0];
      $fluxo[mensal] = $dados_mensais[0];
      $fluxo[semestral] = $dados_semestral[0];

      return $fluxo;
   }

    public function lista_dados(){
      return $this->dados_slave;
    }

    public function lista_tomadas(){
      $dados = $this->banco->getRegistros($this->tabela,array("id_master" => $this->id_master),'*',null,null," id_slave ");
      return $dados;
    }

    public function ativa_desativa_relay(){
      
      //Determina ID do relay
      $id_slave = $this->dados_slave[id_slave];
      $retorno[id_slave] = $id_slave;

      //ler as informações para a conexão do firebase
      $dados = $this->banco->getRegistros('placa_master',array("id_master" => $this->id_master),'*')[0];

      //determina o status a ser alterado do ralay, atavez do que está gravado no banco de dados
      $acao = ($this->dados_slave['status_relay'] === 1 or $this->dados_slave['status_relay'] === '1') ? 0 : 1;
      $at = array( $this->dados_slave['name_path_relay'] => $acao);
      
      //inicia o objeto de conexão do firebase
      $firebase = new \Firebase\FirebaseLib($dados['name_url'], $dados['token']);

      //atualiza a variavel do status do relay no firebase
      $firebase->update($dados['name_path'], $at);
      
      //Realiza leitura do status do relay no firebase após a atualização
      $relay02 = $firebase->get($dados['name_path'].$dados['name_path_relay']);
      $relay_after = json_decode($relay02);
      
      //Verifica se ele foi atualizado mesmo ou se houve falha na atualização.
      if(intval($relay_after->relay) != intval($this->dados_slave['status_relay'])){
        //Caso a atualização seja bem sucedida, o novo status do relay é atualizado no banco de dados
         $this->banco->update($this->tabela,array("status_relay" => $relay_after->relay)," id_slave = '$id_slave' ");
         $retorno[erro] = false;
         $retorno[new_status] = $relay_after->relay;
      }else{
        //Caso a atualização apresente falhas, será retornado uma menssagem de erro
        $retorno[erro] = true;
        $retorno[new_status] = $this->dados_slave['status_relay'];
      }

      return $retorno;

    }

  }
?>