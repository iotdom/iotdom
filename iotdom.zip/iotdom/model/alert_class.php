<?php
class Alerta {
  
  private $id_master;
  private $id_alerta;
  private $dados_alerta;
  private $banco;
  private $tabela = "alertas";


    //Open Connection
    function __construct($banco, $id_master){
      $this->banco = $banco;
      $this->id_master = $id_master;
      $alerta = $this->banco->getRegistros($this->tabela,array("id_master" => $id_master))[0];
      $this->dados_alerta = $alerta;
      $this->id_alerta = $alerta[id_alerta];
    }

    public function update_alerta($dados){
      
      $oper = array();
      
      //Determina ID do alerta
      $id_alerta = $this->id_alerta;

      $retorno = $this->banco->update($this->tabela,$dados," id_alerta = '$id_alerta' ");

      if(empty($retorno['erro'])):
         $mensagem = "Alerta atualizado com sucesso!";
         $oper['erro'] = false;
         $this->dados_alerta = $this->banco->getRegistros($this->tabela,array("id_master" => $this->id_master,"id_alerta" => $this->id_alerta))[0];
      else:
         $mensagem =  $retorno['erro'];
         $oper['erro'] = true;
      endif;
 
     $oper['mensagem'] = $mensagem;
 
     return $oper;
 
     }

    public function lista_dados(){
      return $this->dados_alerta;
    }

    public function ativa_desativa_alerta(){
      
      //Determina ID do alerta
      $id_alerta = $this->id_alerta;

      //determina o status a ser alterado do ralay, atavez do que está gravado no banco de dados
      $acao = $this->dados_alerta['id_ativo'] === "S" ? "N" : "S";
      
      $retorno = $this->banco->update($this->tabela,array("id_ativo" => $acao)," id_alerta = '$id_alerta' ");

      if(empty($retorno['erro'])):
         $mensagem = "Alerta atualizado com sucesso!";
         $oper['erro'] = false;
         $this->dados_alerta = $this->banco->getRegistros($this->tabela,array("id_master" => $this->id_master,"id_alerta" => $this->id_alerta))[0];
         return $this->dados_alerta;
      else:
         $mensagem =  $retorno['erro'];
         $oper['erro'] = true;
         return $retorno;
      endif;

      

    }
    
    public function gera_alerta(){
    
    $dados = $this->dados_alerta;
    
    if($dados[id_ativo] === "S"):
    
    $campos = " sum(vl_kwh) as vl_kwh_total ";
    $condicao = " DATE_FORMAT(dt_leitura_hr, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m') ";
    $mes = $this->banco->getRegistros(" fluxo_kwh ",null,$campos,$condicao)[0]; 
    
    $total_mes = $mes[vl_kwh_total];
    $vl_max = $dados[vl_max_kwh];
    
    $pc_alerta = round(($total_mes * 100) / $vl_max,2);
    
    echo "<script>
           $(document).ready(function(){
           at_alert_analise($this->id_master);
          });
         </script>";
    
    if($pc_alerta < 50){
        echo "<div class='alert alert-success' id='alert_div'>";  
    }elseif($pc_alerta < 80){
        echo "<div class='alert alert-warning' id='alert_div'>"; 
    }else{
        echo "<div class='alert alert-danger' id='alert_div'>";  
    }
    
    echo "
          <strong>Atenção!</strong> Seu consumo mensal já atingiu <strong id='alert_val_txt'>$pc_alerta%</strong>.
         <br> 
         <div class='progress'>
           <div class='progress-bar progress-bar-striped progress-bar-animated' id='alert_bar' style='width:".$pc_alerta."%'>".$pc_alerta."%</div>
         </div>
        </div>";
    
   endif;
   
   }

  }
?>

