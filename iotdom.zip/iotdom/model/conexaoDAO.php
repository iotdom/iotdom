<?php
class Banco {

	private $db_host = 'iotdom.com.br';
	private $db_name = 'iotdom05_iotdom';
	private $db_user = 'iotdom05_admin';
	private $db_pass = 'T5?C2(z],dpx';
  private $db_port = 3306;
  
    private $conn;

    //Open Connection
    function __construct(){
        $dsn = 'mysql:host=' . $this->db_host.';port='.$this->db_port.';dbname=' . $this->db_name;
        $opcoes = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
        if (empty($this->conn)) {
            try {
                $this->conn = new PDO($dsn, $this->db_user, $this->db_pass, $opcoes);
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
    }
 
    public function getRegistros($tabela,$param = null,$campos = '*',$condicao = null,$group = null,$order = null,$limit = null){

        $sql = "SELECT ".$campos." FROM ".$tabela." ";

        if($param !== null or $condicao !== null):
          $sql .= " WHERE ";
         if(!empty($param)):
          $sql .= " 1 ";
          foreach($param as $key => $p): 
            $sql .= " and ".$key." = '".$p."' ";
          endforeach;
         else: 
          $sql .= " ".$condicao." "; 
         endif;
        endif;	

        if($group !== null):
          $sql .= " GROUP BY ".$group." ";
        endif;

        if($order !== null):
          $sql .= " ORDER BY ".$order." ";
        endif;	

        if($limit !== null):
          $sql .= " LIMIT ".$limit." ";
        endif;	
      //print $sql;
        try{
            $db = $this->conn->prepare($sql);
            $db->execute();
        }catch(PDOException $e){
            return $e;
        }

        return $db->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function inserir($tabela,$dados){
        
        $sql = "INSERT INTO ".$tabela." ";
        $keys = "";
        $valores = "";

        if(!empty($dados)):
          foreach($dados as $key => $dado):
          	$keys .= $key.",";
          	$valores .= "'".$dado."',";  
          endforeach;	
        endif;	
        
        //corrige última vírgula
        $keys = substr($keys,0,-1);
        $valores = substr($valores,0,-1);

        $sql .= " ( ".$keys." ) VALUES ( ".$valores." ) ";
        //print $sql;

        try{
    	      $db = $this->conn->prepare($sql);
            $db->execute();
            $retorno['idInsert'] = $this->conn->lastInsertId();
        }catch(PDOException $e){
            $retorno['erro'] = $e;
        }

        return $retorno;

    }
    
    public function update($tabela,$dados,$condicao = null,$aspas = true){
        
        $sql = "UPDATE ".$tabela." SET ";
        $valores = "";

        if(!empty($dados)):
          foreach($dados as $key => $dado):
            if($aspas):
             $valores .= $key." = '".$dado."',";
            else:
             $valores .= $key." = ".$dado.","; 
            endif;   
          endforeach;	
        endif;	
        
        //corrige última vírgula
        $valores = substr($valores,0,-1);

        $sql .= " ".$valores." ";

        if($condicao !== null):
          $sql .= " WHERE ".$condicao; 
        endif;	
      //print $sql;
        try{
    	    $db = $this->conn->prepare($sql);
            $db->execute();
        }catch(PDOException $e){
            return $e;
        }

    }

    public function delete($tabela,$condicao = null){
        
        $sql = "DELETE FROM ".$tabela." ";

        if($condicao !== null):
          $sql .= " WHERE ".$condicao; 
        endif;	

        try{
    	    $db = $this->conn->prepare($sql);
            $db->execute();
        }catch(PDOException $e){
            return $e;
        }

    }
    
}
?>