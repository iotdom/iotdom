<?php
require "biblioteca.php";
/*ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);*/
//Biblioteca Processos Ajax
foreach ($_POST as $nome_campo => $valor):
  $data[$nome_campo] = $valor;
endforeach;

$form = array();
$label = array();

if (!empty($data[form])):
  foreach ($data[form] as $dado):
      
      if(is_string($dado[value])):
       $form[$dado[name]] = utf8_decode($dado[value]);
      else:
       $form[$dado[name]] = $dado[value];
      endif;
      
  endforeach;
endif;

if(!empty($data[label])):
foreach($data[label] as $key => $dado):

 if(is_string($dado)):
       $label[$key] = utf8_decode($dado);
      else:
       $label[$key] = $dado;
 endif;

endforeach; 
endif;


$banco = new Banco();

if($data[funcao] === "at_alert_analise"){
    
   $alerta = new Alerta($banco,$data[id_master]); 
   $dados = $alerta->lista_dados();
    
   $campos = " sum(vl_kwh) as vl_kwh_total ";
   $condicao = " DATE_FORMAT(dt_leitura_hr, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m') ";
   $mes = $banco->getRegistros(" fluxo_kwh ",null,$campos,$condicao)[0]; 
    
   $total_mes = $mes[vl_kwh_total];
   $vl_max = $dados[vl_max_kwh];
    
   $pc_alerta = round(($total_mes * 100) / $vl_max,2);
   
  echo $pc_alerta;
}

if($data[funcao] === "calc_tarifas"){
    
   $kwh = remove_val_mask(str_replace("kWh","",$data[kwh]));
   $val = valor_tarifas($kwh,"D");
   $legenda_tar = legenda_tarifas();
   $class = array("V" => " class='table-success' ", "A" => " class='table-warning' ", "V1" => " class='table-danger' ", "V2" => " class='table-danger' ");
   
   ?>
    <div class="table-responsive">
     <table class="table table-condensed table-bordered table-hover">
      <thead>
       <tr>
        <th>Bandeira</th>
        <th>kWh</th>
        <th>Tarifa TE <i class="fas fa-info-circle" data-toggle="tooltip" title="Tarifa de Energia TE (R$/kWh)"></i></th>
        <th>Tarifa TUSD <i class="fas fa-info-circle" data-toggle="tooltip" title="Tarifa do Uso do Sistema de Distribuição (TUSD)(R$/kWh)"></i></th>
        <th>Tarifa Bandeira <i class="fas fa-info-circle" data-toggle="tooltip" title="Bandeiras Tarifárias"></i></th>
        <th>Val. TE</th>
        <th>Val. TUSD</th>
        <th>Val. Bandeira</th>
        <th>Val. Total</th>
       </tr>
      </thead>
      <tbody>
       <?
        foreach($legenda_tar as $key => $tar):
       ?>
        <tr <?=$class[$key]?> >
         <th><?=$tar?></th>
         <td><?=$data[kwh]?></td>
         <td><?=masc_num4($val['taxa_te'])?></td>
         <td><?=masc_num4($val['taxa_tusd'])?></td>
         <td><?=masc_num4($val['taxa_bandeira_'.$key])?></td>
         <td><?=masc_num2($val['vl_te'])?></td>
         <td><?=masc_num2($val['vl_tusd'])?></td>
         <td><?=masc_num2($val['vl_bandeira_'.$key])?></td>
         <td><?=masc_num2($val['vl_total_'.$key])?></td>
        </tr>
       <?
        endforeach;
       ?>
      </tbody>
     </table>
    </div>
    <br />
    <div class="alert alert-info">
     <strong>Atenção!</strong><br/>*Os valores apresentados não incluem os tributos (ICMS,PIS/COFINS) e a Contribuição de Iluminação Municipal - CIP.*<br/>**Os percentuais apresentados divergem dos valores apresentados na fatura, pois não incluem tributos.**
    </div>
   <?
}


/*

if($data[funcao] === "get_dados_slave"){
  $relay = new Slave($banco,$data[id_master],$data[id_slave]);
  $dados = $relay->lista_dados();
  require_once "../view/form_tomada.php";
  //echo json_encode($result);
}

if($data[funcao] === "carrega_tomadas"){
  require_once "../view/tomada.php";
  //echo json_encode($result);
}*/

?>