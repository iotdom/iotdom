<?php

function get_comodos(){
  $banco = new Banco();
  $dados = $banco->getRegistros("comodos",null,'*',null,null," ds_comodo ");
  return $dados;
}

function get_aparelhos(){
  $banco = new Banco();
  $dados = $banco->getRegistros("aparelhos",null,'*',null,null," ds_aparelho ");
  return $dados;
}

function mask_hora($hora){
 $hora = substr($hora,0,-3);
 return $hora;
}

function remove_val_mask($n){
    $n = str_replace(".","",$n);
    $n = str_replace(",",".",$n);
    return $n;
}

function get_relay_ativos(){
   $banco = new Banco();
   $condicao = " status_relay = 1 or status_relay = 0 ";
   $dados_tomada = $banco->getRegistros(" placa_slave ",null,"id_slave",$condicao,null,'id_slave'); 
   return $dados_tomada;
}

function masc_num4($num){
    return number_format($num, 4, ',', '.');
}

function masc_num2($num){
    return number_format($num, 2, ',', '.');
}

function get_consumo_diario($dt_ini,$dt_fim){
   $banco = new Banco();
   $retorno[legenda] = array("Matutino","Vespertino","Noturno");
   
   $tabela = "fluxo_kwh";
   $campos = "
    round(SUM((CASE WHEN ((DATE_FORMAT(dt_leitura_hr, '%H:%i:%s') >= '06:00') AND (DATE_FORMAT(dt_leitura_hr, '%H:%i:%s') < '12:00')) THEN vl_kwh END)),4) AS Mkpotencia,
	round(SUM((CASE WHEN ((DATE_FORMAT(dt_leitura_hr,'%H:%i:%s') >= '12:00') AND (DATE_FORMAT(dt_leitura_hr, '%H:%i:%s') < '18:00')) THEN vl_kwh END)),4) AS Tkpotencia,
	round(SUM((CASE WHEN ((DATE_FORMAT(dt_leitura_hr, '%H:%i:%s') >= '18:00') AND (DATE_FORMAT(dt_leitura_hr, '%H:%i:%s') < '6:00')) THEN vl_kwh END)),4) AS Nkpotencia
   ";
   $condicao = " (DATE_FORMAT(dt_leitura_hr,'%Y:%m:%d') >= DATE_FORMAT('$dt_ini', '%Y:%m:%d')) and (DATE_FORMAT(dt_leitura_hr,'%Y:%m:%d') <= DATE_FORMAT('$dt_fim', '%Y:%m:%d')) ";

   $dados_tomada = $banco->getRegistros($tabela,null,$campos,$condicao)[0]; 
   $retorno[dados] = array($dados_tomada[Mkpotencia],$dados_tomada[Tkpotencia],$dados_tomada[Nkpotencia]);
   return $retorno;
}

function meses(){
    $meses['01'] = "Janeiro";
    $meses['02'] = "Fevereiro";
    $meses['03'] = "Março";
    $meses['04'] = "Abril";
    $meses['05'] = "Maio";
    $meses['06'] = "Junho";
    $meses['07'] = "Julho";
    $meses['08'] = "Agosto";
    $meses['09'] = "Setembro";
    $meses['10'] = "Outubro";
    $meses['11'] = "Novembro";
    $meses['12'] = "Dezembro";
    
    return $meses;
}

function get_consumo_financeiro($tp_grafico){
   $banco = new Banco();
   
   if($tp_grafico === "M"):
    
    $tabela = " fluxo_kwh ";
    $campos = " sum(vl_kwh) as kwh_mes, date_format(dt_leitura_hr,'%m') mes ";
    $group = " date_format(dt_leitura_hr,'%Y-%m') ";
    $condicao = " date_format(dt_leitura_hr,'%Y') = date_format(NOW(),'%Y') ";
   
    $dados_tomada = $banco->getRegistros($tabela,null,$campos,$condicao,$group);
    
    
    $consumo_mensal = array_fill(1, 12, 0);
    
    foreach($dados_tomada as $tom):
     $consumo_mensal[intval($tom[mes])] = $tom[kwh_mes];
    endforeach;
    
    foreach($consumo_mensal as $key => $con):
     $vl_consumo_mensal[$key] = valor_tarifas($con);
    endforeach;
   
   endif;

   return $vl_consumo_mensal;
}

function get_last_data_chart_real_time(){
    $banco = new Banco();
    
    $condicao = "";
    
    $ids_relay_ativos = get_relay_ativos();
    
    if($ids_relay_ativos !== null and !empty($ids_relay_ativos)):
     $condicao .= " ( ";
     $aux = 0;
     foreach($ids_relay_ativos as $id):
      $condicao .= $aux > 0 ? " or " : "";
      $condicao .= " id_slave = $id[id_slave] ";
      $aux++;
     endforeach;
     $condicao .= " ) ";
    endif;
    
    if($condicao !== ""):
    $dados_tomada = $banco->getRegistros(" placa_slave ",null,"id_slave,name_relay,color",$condicao,null,'id_slave');
    foreach($dados_tomada as $tom):
     $dados_retorno[$tom[id_slave]][id_slave] = $tom[id_slave];
     $dados_retorno[$tom[id_slave]][color] = $tom[color];
     $dados_retorno[$tom[id_slave]][name_relay] = $tom[name_relay];
     $dados_corrente = null;
     $dados_corrente = $banco->getRegistros(" fluxo_corrente ",array("id_slave" => $tom[id_slave]),"*",null,null," dt_leitura DESC ",1)[0];
     $dados_retorno[$tom[id_slave]][kpotencia] = round( (floatval($dados_corrente[vl_corrente]) * floatval($dados_corrente[tp_tensao]) / 1000), 3) ;
    endforeach;
    endif;
    return $dados_retorno;
}

function get_consumo_total($tipo){
   $banco = new Banco();
   $campos = " sum(vl_kwh) as vl_kwh_total, id_slave ";
   $group = " id_slave ";
   
   if($tipo === "D"):
    $condicao = " DATE_FORMAT(dt_leitura_hr, '%Y-%m-%d') = DATE_FORMAT(NOW(), '%Y-%m-%d') ";
   elseif($tipo === "S"):
    $condicao = " DATE_FORMAT(dt_leitura_hr, '%Y-%m-%d') >= DATE_FORMAT( (NOW() - INTERVAL 6 DAY), '%Y-%m-%d') and DATE_FORMAT(dt_leitura_hr, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m') ";
   elseif($tipo === "M"):
    $condicao = " DATE_FORMAT(dt_leitura_hr, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m') ";
   endif; 
   
   $dados = $banco->getRegistros(" fluxo_kwh ",null,$campos,$condicao,$group); 
   return $dados;
}

function get_pis_cofins($date = null){  
    $banco = new Banco();
    $date = $date != null ? $date : date("Y-m-d");
    $condicao = " date_format(dt_valida,'%Y-%m') = date_format('$date','%Y-%m')  ";
    $pc_pis_cofins = $banco->getRegistros(" tab_pis_cofins ",null,"*",$condicao)[0];
    return $pc_pis_cofins;   
}

function get_pc_icms($kwh){
    $banco = new Banco();
    $condicao = " $kwh >= min_kwh and $kwh <= max_kwh ";
    $dados_icms = $banco->getRegistros(" tab_icms ",null,"*",$condicao)[0];
    $pc_icms = $dados_icms[pc_icms];
    return $pc_icms;
}

function valor_tarifas($kwh,$tp = "T"){
    
   $banco = new Banco();
   $campos = " * "; 
   
   $dados_tarifas_bandeiras = $banco->getRegistros(" tarifas_bandeiras ");
   
   $valor_tarifas = $banco->getRegistros(" tarifas ")[0];
   
   $vl_te = round($valor_tarifas[vl_te] * $kwh,2);
   $vl_tusd = round($valor_tarifas[vl_tusd] * $kwh,2);
   
  if($tp === "D"): 
   $tarifa[taxa_te] = $valor_tarifas[vl_te];
   $tarifa[taxa_tusd] = $valor_tarifas[vl_tusd];
   
   $tarifa[vl_te] = $vl_te;
   $tarifa[vl_tusd] = $vl_tusd;

   foreach($dados_tarifas_bandeiras as $b):
     $tarifa["taxa_bandeira_".$b[tp_bandeira]] = $b[vl_tarifa_add];
     $tarifa["vl_bandeira_".$b[tp_bandeira]] = round($kwh * $b[vl_tarifa_add],2);
     $tarifa["vl_total_".$b[tp_bandeira]] = $tarifa["vl_bandeira_".$b[tp_bandeira]] + $vl_te + $vl_tusd;
   endforeach;
   elseif($tp === "T"):
    foreach($dados_tarifas_bandeiras as $b):
     $vl_bandeira = round($kwh * $b[vl_tarifa_add],2);
     $tarifa[$b[tp_bandeira]] = $vl_bandeira + $vl_te + $vl_tusd;
   endforeach;
   
   endif;
    
   return $tarifa;
}

function legenda_tarifas(){
   $banco = new Banco();
   $campos = " * "; 
   $dados_tarifas = $banco->getRegistros(" tarifas_bandeiras ");
   
   foreach($dados_tarifas as $t):
    $tarifa[$t[tp_bandeira]] = $t[nm_bandeira];
   endforeach;
    
   return $tarifa;
}

?>