<?php
$tomadas = new Slave($banco,$_SESSION['id_master']);
$lista = $tomadas->lista_tomadas();
?>
<!DOCTYPE>
<html>
 <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
 </head>
 <body>
 <div class="container-fluid">
  <div class="row">
   <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="page-header">
     <h3 class="mb-2">Tomadas</h3>
     <hr/>
    </div>
   </div>
   </div>
   <div class='row justify-content-center'>
   <div class="card-columns">
   <?php
    foreach($lista as $tom):
      if($tom[status_relay] === 1 or $tom[status_relay] === "1"):
        $color_status = "border-success";
        $color_button = " btn-outline-success";
        $btn_ativo = "";
        $img_status = "img/lighting.png";
      elseif($tom[status_relay] === 0 or $tom[status_relay] === "0"):
        $color_status = "border-danger";
        $color_button = " btn-outline-danger";
        $btn_ativo = "";
        $img_status = "img/plug.png";
      else:
        $color_status = "border-secondary";  
        $color_button = " btn-outline-secondary";
        $btn_ativo = "disabled";
        $img_status = "img/plug.png";
      endif;  
   ?> 
       <div id='card_tomada_<?=$tom[id_slave]?>' class="card text-center <?=$color_status?> ">
       <div id='card_tomada_<?=$tom[id_slave]?>_header' class="card-header <?=$color_status?>">
       <div class='row justify-content-end'> 
        <a type="button" class="btn btn-light" onclick="form_tomada('<?=$_SESSION[id_master]?>','<?=$tom[id_slave]?>')" ><i class="fas fa-cog"></i></a>
        </div>
        <div class='row justify-content-md-center'> 
         <?=$tom[name_relay]?>
        </div>   
       </div>
         <div class="card-body card_tomada_img">
          <img id='card_tomada_<?=$tom[id_slave]?>_img' class="card-img" src="<?=$img_status?>" alt="Card image"> 
         </div>
         <div id='card_tomada_<?=$tom[id_slave]?>_footer' class="card-footer <?=$color_status?>">
          <a id='card_tomada_<?=$tom[id_slave]?>_button' type="button" class="btn <?=$color_button?> btn-lg btn-block " <?=$btn_ativo?> onclick="ativa_desativa_relay('<?=$_SESSION[id_master]?>','<?=$tom[id_slave]?>')" ><i class="fas fa-power-off"></i></a>
        </div> 
       </div> 
   <?
    endforeach;
   ?>
  </div>
  </div>
  </div> 
<!-- Modal -->
<div class="modal fade" id="modal_form_tomada" tabindex="-1" role="dialog" aria-labelledby="modal_tomada" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tomada</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form name='cad_tomada' id='cad_tomada'>
      <input type='hidden' name='id_tomada' id='id_tomada' value="" >
      <div class="row">
         <div class="col-md">
          <label>Descrição</label>
          <input type="text" class="form-control" id="ds_relay" name="ds_relay" value="" required>
         </div>
       </div>
       <br/>
       <div class="row">
         <div class="col-md">
          <label>Tensão</label>
           <select name='tp_tensao' id='tp_tensao' class="form-control">
            <option value='110'>110V</option>
            <option value='220'>220v</option>
           </select>
         </div>
       </div>
        <br/> 
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <button type="button" class="btn btn-primary validar_gravar" onclick = "grava_tomada('cad_tomada')">Gravar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="modal_tomada" tabindex="-1" role="dialog" aria-labelledby="modal_tomada" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">tomada</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form name='cad_tomada' id='cad_tomada'>
      <input type='hidden' name='id_tomada' id='id_tomada' value="" >
      <div class="row">
         <div class="col-md">
          <label>Descrição</label>
          <input type="text" class="form-control" id="ds_tomada" name="ds_tomada" value="" required>
         </div>
         </div>
        <br/> 
       <div class="row">
         <div class="col-md-6">
          <label>Número</label>
          <input type="text" class="form-control" id="nr_tomada" name="nr_tomada" value="" required>
         </div>
         <div class="col-md-6">
          <label>Código Unidade</label>
          <input type="text" class="form-control" id="cd_unidade" name="cd_unidade" value="" required>
         </div>
         </div>
         <br/> 
         <div class="row"> 
         <div class="col-md">
          <label>Tipo</label>
          <select class="form-control" id="tp_tomada" name="tp_tomada" required>
           <option value='P'>Pública</option>
           <option value='V'>Privada</option>
          </select>
         </div>
         </div>
         <br/> 
         <div>
          <p class='titulo'>Períodos de Funcionamento</p>
         </div>
         <div class='row'>
         <div class="col-md-4">
          <div class="custom-control custom-checkbox">
           <input type="checkbox" class="custom-control-input" id="op_manha" name="op_manha">
           <label class="custom-control-label" for="op_manha">Manhã</label>
           </div>
         </div>
         <div class="col-md-4">
          <div class="custom-control custom-checkbox">
           <input type="checkbox" class="custom-control-input" id="op_tarde" name="op_tarde">
           <label class="custom-control-label" for="op_tarde">Tarde</label>
           </div>
         </div>
         <div class="col-md-4">
          <div class="custom-control custom-checkbox">
           <input type="checkbox" class="custom-control-input" id="op_noturno" name="op_noturno">
           <label class="custom-control-label" for="op_noturno">Noturno</label>
           </div>
         </div>
         </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <button type="button" class="btn btn-primary validar_gravar" onclick = "grava_tomada('cad_tomada')">Gravar</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>