<?php
class Master {
  
  private $id_master;
  private $dados_master;
  private $banco;
  private $tabela = "placa_master";


    //Open Connection
    function __construct($banco,$id_master = null){
      $this->banco = $banco;
      $this->id_master = $id_master;
        if(!empty($id_master)):
          $dados_master = $this->banco->getRegistros($this->tabela,array("id_master" => $id_master));
          $this->dados_master = $dados_master;
        endif; 
    }

    public function inicia_session($dados){
      foreach($dados as $key => $dado):
        $_SESSION[$key] = $dado;
      endforeach;
      $_SESSION['autenticado'] = true; 
      $this->id_master =  $_SESSION['id_master']; 
   } 

   public function valida_login($dados){
    
    $oper = array();

    $retorno = $this->banco->getRegistros($this->tabela,array("login_usu" => $dados['login_usuario']))[0];

    if(empty($retorno)):
      $mensagem = "Usuário não encontrado!";
      $valido = false;
    else:
     
     $valido = $retorno['senha_usu'] !== $dados['senha_usuario'] ? false : true;
     $mensagem = $valido ? "" : "Senha digitada inválida";

     if($valido):
       $this->inicia_session($retorno);
     endif;  

    endif;

   $oper['valido'] = $valido;
   $oper['mensagem'] = $mensagem;
   //var_dump($oper);
   return $oper;
   }
   

   public function logoff(){
      session_unset();
      session_destroy();
      header('Location: index.php');    
   }

   public function lista_dados(){
      return $this->dados_master;
   }

  }
?>