<?php
session_start();
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
error_reporting(0);
require_once('conexaoDAO.php');
require_once('firebase-php-master/src/firebaseLib.php');
require_once('master_class.php');
require_once('relay_class.php');
require_once('alert_class.php');
require_once('funcoes.php');
$banco = new Banco();
?>