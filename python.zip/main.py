flag = True
prevAmpValue = 0
newValue = 0
count = 0
mailCheck = 0
hrOnFlag = 0
hrOffFlag = 0
setDB = 0
while True:
    try:
        import sms

        import send

        import re

        import mysql.connector

        from firebase import firebase

        from func import getAmp

        from time import sleep

        from datetime import date
        from datetime import datetime

        import hashlib

        dt = datetime.today().replace(day=1).day
        td = datetime.today().day

        #print(dt.day)
        today = date.today()
        now = datetime.now()
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        s_now = (now - midnight).seconds
        print("Hora agora em segundos: " + str(s_now))

        if int(s_now) < 20 :
            hrOnFlag = 0
            hrOffFlag = 0

        sleep(0.0)

        firebase = firebase.FirebaseApplication("https://iotdom.firebaseio.com/", None)

        info = firebase.get('', None)
        #firebase.put('/CASA', 'relay', 5)
        ampValue = firebase.get('/CASA/SCT013', None)
        relayStatus = firebase.get('/CASA/relay', None)

        ampValue2 = (float(ampValue)+3)*float(ampValue)
        ampValue3 = (float(ampValue)*float(ampValue))+1
        ampValue4 = float(ampValue)*5-3

        if ampValue4 < 0 : ampValue4 = float(ampValue4)*-1

        print("valor corrente: " + str(ampValue))
        print("status do relay: " + str(relayStatus))

        #if portId is None or portId == '' : print("noESP32ID")

        #print(getAmp(str(info)))

        iotdom = mysql.connector.connect(
          host="iotdom.com.br",
          user="iotdom05_admin",
          password="T5?C2(z],dpx",
          database="iotdom05_iotdom"
        )

        if ampValue == prevAmpValue : count += 1
        if count == 10 : flag = False
        if ampValue != prevAmpValue:
            flag = True
            count = 1

        prevAmpValue = ampValue

        queryCursor = iotdom.cursor()
        hrOn = "SELECT relay_hr_on FROM placa_slave WHERE name_relay='Setup PC'"
        hrOff = "SELECT relay_hr_off FROM placa_slave WHERE name_relay='Setup PC'"
        qry = "INSERT INTO fluxo_corrente (vl_corrente, relay_status, dt_leitura, id_slave) VALUES (%s, %s, %s, %s)"
        input = (str(ampValue), str(relayStatus), str(now.strftime("%Y-%m-%d %H:%M:%S")), '1')

        qry2 = "INSERT INTO fluxo_corrente (vl_corrente, relay_status, dt_leitura, id_slave) VALUES (%s, %s, %s, %s)"
        input2 = (str(ampValue2), str(relayStatus), str(now.strftime("%Y-%m-%d %H:%M:%S")), '2')

        qry3 = "INSERT INTO fluxo_corrente (vl_corrente, relay_status, dt_leitura, id_slave) VALUES (%s, %s, %s, %s)"
        input3 = (str(ampValue3), str(relayStatus), str(now.strftime("%Y-%m-%d %H:%M:%S")), '3')

        qry4 = "INSERT INTO fluxo_corrente (vl_corrente, relay_status, dt_leitura, id_slave) VALUES (%s, %s, %s, %s)"
        input4 = (str(ampValue4), str(relayStatus), str(now.strftime("%Y-%m-%d %H:%M:%S")), '4')

        qryOff = "UPDATE placa_slave SET status_relay = '0'"  # WHERE id_slave = '1'"
        # inputOff = 0

        qryOn = "UPDATE placa_slave SET status_relay = '1'" #WHERE id_slave = '1'"
        #inputOn = 1

        qryErr = "UPDATE placa_slave SET status_relay = '2'" #WHERE id_slave = '1'"
        #inputErr = 2

        qryCheckRelayStatus = "SELECT status_relay FROM placa_slave WHERE id_slave = '1'"

        qryCheckMail = "SELECT flag_email_enviado FROM alertas"
        qrySentMail = "UPDATE alertas SET flag_email_enviado = 'S'"

        #pw = "Tamandua@2020"
        #password = hashlib.sha256(pw.encode()).hexdigest()
        #qry2 = "INSERT INTO idle_current_probing (id_slave, tp, idle, current) VALUES (%s, %s, %s, %s)"
        #input2 = ("1", "ligado", "n/a", str(ampValue))

        queryCursor.execute(hrOn)
        hrOn_value = queryCursor.fetchall()
        print("Hora On value RAW: " + str(hrOn_value))
        queryCursor.execute(hrOff)
        hrOff_value = queryCursor.fetchall()
        print("Hora Off value RAW: " + str(hrOff_value))
        hrOn_value = re.sub('[^0-9]+', '', str(hrOn_value))
        hrOff_value = re.sub('[^0-9]+', '', str(hrOff_value))
        print("Hora On value Num: " + hrOn_value)
        print("Hora Off value Num: " + hrOff_value)

        # queryCursor.execute(query)
        # print(queryCursor.fetchall())
        if flag:
            queryCursor.execute(qryCheckRelayStatus)
            if re.sub('[^0-9]+', '', str(queryCursor.fetchone())) == 2 : firebase.put('/CASA', 'relay', 0)
            #if str(relayStatus) == 1 : firebase.put('/CASA', 'relay', 1)
            if setDB == 0 : queryCursor.execute(qryOff)
            queryCursor.execute(qry, input)
            queryCursor.execute(qry2, input2)
            queryCursor.execute(qry3, input3)
            queryCursor.execute(qry4, input4)
            print("Dados inseridos no DB.")
            mailCheck = 1
            setDB = 1

        if not flag:
            firebase.put('/CASA', 'relay', 0)
            queryCursor.execute(qryErr)
            print("Erro. Relay foi desligado e dados nao inseridos.")
            if mailCheck == 1 : send.email()
            mailCheck = 0
            setDB = 0

        # if flag : queryCursor.execute(qry, input) else : queryCursor.execute(qry, input)
        # queryCursor.execute(qry2, input2)

        print("Error counter: " + str(count))
        #print(ampValue)
        #print(prevAmpValue)
        print("Exec flag: " + str(flag))

        #a fazer: desligar o relay no firebase por horario falhou

        print("hrOffFlag before condition: " + str(hrOffFlag))
        print("hrOnFlag before condition: " + str(hrOnFlag))

        if str(hrOn_value).isnumeric() and relayStatus == 0:
            print(" - hrOn is numeric and relaystatus: " + str(relayStatus))
            if int(hrOn_value) < int(s_now) :
                print(str("hora on: " + str(int(hrOn_value))) + " hora now: " + str(int(s_now)))
                if hrOnFlag == 0 :
                    print("Deu hora on")
                    firebase.put('/CASA', 'relay', 1)
                    queryCursor.execute(qryOn)
                    hrOnFlag = 1

            #a fazer: colocar valor 1 na coluna status_relay id = 1

        if str(hrOff_value).isnumeric() and relayStatus == 1:
            print(" - hrOff is numeric.")
            if int(hrOff_value) < int(s_now) :
                print(str("hora off: " + str(int(hrOff_value))) + " hora now: " + str(int(s_now)))
                if hrOffFlag == 0 :
                    print("Deu hora off")
                    firebase.put('/CASA', 'relay', 0)
                    queryCursor.execute(qryOff)
                    hrOffFlag = 1

            # a fazer: colocar valor 0 na coluna status_relay id = 1
            #flag = False

        # if openvioemail for 1 fazer, se for 0 pular

        qryOp = "SELECT op_envio_email FROM alertas"
        qryCheckMail = "SELECT flag_email_enviado FROM alertas"
        qrySetMailSentOne = "UPDATE alertas SET flag_email_enviado = '1'"
        qrySetMailSentZero = "UPDATE alertas SET flag_email_enviado = '0'"
        qryKwh = "SELECT sum(vl_kwh) FROM fluxo_kwh where date_format(dt_leitura_hr,\"%Y-%m\") = date_format(now(),\"%Y-%m\")"
        qryKwhLimit = "SELECT vl_max_kwh from alertas"

        print("se " + str(dt) + " for igual a dia de hoje " + str(td) + " zerar a flag de email enviado.")

        # mudar if de dia para hora meia noite, segundos se possivel
        if str(dt) == str(td): queryCursor.execute(qrySetMailSentZero)

        queryCursor.execute(qryOp)
        mailOp = re.sub('[^0-9]+', '', str(queryCursor.fetchone()))
        print("opcao de envio - " + mailOp)

        queryCursor.execute(qryCheckMail)
        # print("email enviado? - " + re.sub('[^0-9]+', '', str(queryCursor.fetchone())))
        mailSentFlag = re.sub('[^0-9]+', '', str(queryCursor.fetchone()))
        print("mail enviado? - " + mailSentFlag)

        # queryCursor.execute(qrySetMailSentZero)

        queryCursor.execute(qryKwh)
        # print(re.sub('[^0-9.]+', '', str(queryCursor.fetchone())) + " kwh")
        kwh = re.sub('[^0-9.]+', '', str(queryCursor.fetchone()))
        print("consumo atual: " + kwh + " kwh")

        queryCursor.execute(qryKwhLimit)
        # print("limite solicitado: " + re.sub('[^0-9.]+', '', str(queryCursor.fetchone())) + " kwh")
        kwhLimit = re.sub('[^0-9.]+', '', str(queryCursor.fetchone()))
        print("limite programado: " + kwhLimit + " kwh")

        if kwh > kwhLimit and mailSentFlag == '0':
            print("consumo maior que programado")
            #pegar email do DB
            send.email(kwh, "nathan-brazil@hotmail.com")
            to = 55959713525
            text = 'Seu limite pre-definido de + ' + str(kwhLimit) + ' foi atingido.'
            sms.sendSms(to, text)

            print("email enviado")
            queryCursor.execute(qrySetMailSentOne)
        else:
            print("consumo menor que o programado ou email ja enviado")
            print("email nao enviado")

        qryCheckRelayStatus = "SELECT status_relay FROM placa_slave WHERE id_slave = '1'"
        queryCursor.execute(qryCheckRelayStatus)
        print(re.sub('[^0-9]+', '', str(queryCursor.fetchone())))

        print("hrOffFlag after condition: " + str(hrOffFlag))
        print("hrOnFlag after condition: " + str(hrOnFlag))
        print(ampValue)
        print(ampValue2)
        print(ampValue3)
        print(ampValue4)
        print("")
        print("-------------------------------------------")
        print("")
    except:
        print("")
        print("-------------------------------------------")
        print("")
        print("Error catched, please verify.")
        print("")
        print("-------------------------------------------")
        print("")
        continue
