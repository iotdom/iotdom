import nexmo
def sendSms(to, text):
    client = nexmo.Sms(key='5d3b036e', secret='Se5lyHKcZzZsiUPm')

    client.send_message({
        'from': 'IOTDOM',
        'to': to,
        'text': text,
})